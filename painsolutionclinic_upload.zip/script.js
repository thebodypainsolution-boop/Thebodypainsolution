function login(){
  const u=document.getElementById('uid').value;
  const p=document.getElementById('pwd').value;
  if(u==='thepainbodysolution' && p==='12345'){
    document.getElementById('login').style.display='none';
    document.getElementById('app').style.display='block';
  } else alert('Wrong ID or Password');
}

function showPage(id){
  document.querySelectorAll('.page').forEach(p=>p.style.display='none');
  document.getElementById(id).style.display='block';
}

function addImage(e){
  const file=e.target.files[0];
  const reader=new FileReader();
  reader.onload=function(evt){
    const img=document.createElement('img');
    img.src=evt.target.result;
    document.getElementById('imgArea').appendChild(img);
  }
  reader.readAsDataURL(file);
}
